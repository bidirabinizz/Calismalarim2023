import React from "react";

function loginsuccess() {
  return <div>loginsuccess</div>;
}

export default loginsuccess;
