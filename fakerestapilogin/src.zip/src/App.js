import React from "react";
import Girisyap from "./components/Girisyap";

function App() {
  return (
    <div>
      <Girisyap></Girisyap>
    </div>
  );
}

export default App;
